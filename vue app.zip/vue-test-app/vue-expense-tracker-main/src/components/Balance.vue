<template>
  <div class="balance-container">
    <div class="circle-container">
      <div class="circle" :style="{ transform: circleTransform }"></div>
      <div class="balance-value">${{ total }}</div>
    </div>
    <p class="uppercase-text">Total Balance</p>
  </div>
</template>

<script setup>
import { defineProps, computed } from 'vue';

const props = defineProps({
  total: {
    type: Number,
    required: true,
  },
});

const gradientBackground = computed(() => {
  const percentage = Math.min((props.total / 1000) * 100, 50); // Assuming total balance is out of 1000, limiting the loader to 50%
  return `conic-gradient(#4CAF50 ${percentage}%, transparent ${percentage + 1}%)`;
});

const circleTransform = computed(() => {
  const rotation = (props.total / 1000) * 360; // Assuming total balance is out of 1000
  return `rotate(${rotation}deg)`;
});
</script>

<style>
.balance-container {
  text-align: center;
}

.circle-container {
  position: relative;
  width: 200px;
  height: 200px;
  margin: 0 auto;
}

.circle {
  position: absolute;
  width: calc(100% - 20px);
  height: calc(100% - 20px);
  border-radius: 50%;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
  background: radial-gradient(circle at center, transparent 70%, rgba(0, 0, 0, 0.5) 70%);
  transition: transform 0.5s ease;
}

.balance-value {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 24px;
  font-weight: bold;
}

.uppercase-text {
  text-transform: uppercase;
}
</style>
