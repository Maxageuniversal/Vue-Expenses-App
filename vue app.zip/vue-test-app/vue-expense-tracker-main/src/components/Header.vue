<template>
  <div class="draggable"
    @mousedown="startDrag"
    @touchstart="startDrag"
    @mousemove="onDrag"
    @touchmove="onDrag"
    @mouseup="stopDrag"
    @touchend="stopDrag"
    @mouseleave="stopDrag"
    @mouseenter="showNotification">

    <!-- Draggable icon -->
    <div class="draggable-icon">
      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-drag-vertical" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <line x1="4" y1="6" x2="20" y2="6" />
        <line x1="4" y1="12" x2="20" y2="12" />
        <line x1="4" y1="18" x2="20" y2="18" />
      </svg>
    </div>

    <!-- Notification for draggable -->
    <div v-if="showDragNotification" class="drag-notification">
      Overview
    </div>

    <h2 :style="{ color: '#FFF' }">Overview</h2>

    <!--  -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      showDragNotification: false,
      // Your other data properties
    };
  },
  methods: {
    // Your existing methods
  
    showNotification() {
      this.showDragNotification = true;
      setTimeout(() => {
        this.showDragNotification = false;
      }, 2000); // Hide notification after 2 seconds
    }
  }
};
</script>

<style scoped>
  .draggable {
    position: relative;
    cursor: grab;
    /* Add other styles as needed */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Shadow effect */
    transition: opacity 0.3s ease;
  }

  .draggable:hover {
    opacity: 0.9; /* Opacity change on hover */
  }

  .draggable-icon {
    position: absolute;
    top: 5px;
    left: 5px;
    opacity: 0; /* Initially hide the draggable icon */
    transition: opacity 0.3s ease;
    z-index: 1;
  }

  .draggable-icon svg {
    width: 20px;
    height: 20px;
    fill: #000; /* Adjust color as needed */
  }

  .drag-notification {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: rgba(0, 0, 0, 0.8);
    color: #fff;
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 14px;
    z-index: 2;
  }

</style>
