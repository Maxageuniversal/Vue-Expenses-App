<template>
  <div>
    <div class="inc-exp-container">
      <div class="chart-container">
        <h4>Income</h4>
        <div class="chart-wrapper">
          <canvas id="incomeChart" width="144" height="200"></canvas>
        </div>
        <div class="center-label">+${{ income }}</div>
      </div>
      <div class="chart-container">
        <h4>Expense</h4>
        <div class="chart-wrapper">
          <canvas id="expenseChart" width="144" height="200"></canvas>
        </div>
        <div class="center-label">-${{ expenses }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { defineProps, onMounted } from 'vue';
import Chart from 'chart.js/auto';
import 'chartjs-plugin-datalabels';

const props = defineProps({
  income: {
    type: Number,
    required: true,
  },
  expenses: {
    type: Number,
    required: true,
  },
});

onMounted(() => {
  const incomeChart = new Chart(document.getElementById('incomeChart'), {
    type: 'bar',
    data: {
      labels: ['Date 1', 'Date 2', 'Date 3'], // Replace with your date labels
      datasets: [{
        label: 'Income',
        data: [10, 20, 15], // Replace with your income data
        backgroundColor: 'rgba(54, 162, 235, 0.8)', // Darker blue color
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        datalabels: {
          color: '#000',
          anchor: 'end',
          align: 'top',
          formatter: function(value, context) {
            return '$' + value;
          }
        }
      },
      animation: {
        duration: 2000, // Animation duration in milliseconds
      }
    },
  });

  const expenseChart = new Chart(document.getElementById('expenseChart'), {
    type: 'bar',
    data: {
      labels: ['Date 1', 'Date 2', 'Date 3'], // Replace with your date labels
      datasets: [{
        label: 'Expenses',
        data: [5, 10, 8], // Replace with your expenses data
        backgroundColor: 'rgba(255, 99, 132, 0.8)', // Darker red color
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        datalabels: {
          color: '#000',
          anchor: 'end',
          align: 'top',
          formatter: function(value, context) {
            return '$' + value;
          }
        }
      },
      animation: {
        duration: 2000, // Animation duration in milliseconds
      }
    },
  });
});
</script>

<style>
.inc-exp-container {
  display: flex;
  justify-content: space-around;
}

.chart-container {
  text-align: center;
  margin: 10px;
}

.chart-wrapper {
  position: relative;
}

/* Add CSS animation for motion effect */
@keyframes chartMotion {
  0% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
  100% {
    transform: translateY(0);
  }
}

canvas {
  animation: chartMotion 2s infinite; /* Apply animation to canvas */
}
</style>
